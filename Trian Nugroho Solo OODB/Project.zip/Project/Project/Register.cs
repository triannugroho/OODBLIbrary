﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Register : Form
    {
        Login login = null;

        private DataClasses1DataContext dc = new DataClasses1DataContext();

        public Register()
        {
            InitializeComponent();
            //generateUserId();
        }


        private void validate()
        {
            if (txtName.Text.Equals(""))
            {
                MessageBox.Show("Name must be filled");
            }
            else if (txtEmail.Text.Equals(""))
            {
                MessageBox.Show("Email must be filled");
            }
            else if (txtEmail.Text.Length < 5 && txtEmail.Text.Length > 30)
            {
                MessageBox.Show("Email must be between 5 – 30 characters");
            }
            else if (!txtEmail.Text.Contains("@") && !txtEmail.Text.Contains("."))
            {
                MessageBox.Show("Email must contain ‘@’ and ‘.’ sign");
            }
            else if (txtEmail.Text.StartsWith("@") || txtEmail.Text.StartsWith(".") || txtEmail.Text.EndsWith("@") || txtEmail.Text.EndsWith("."))
            {
                MessageBox.Show("‘@’ and ‘.’ sign cannot be placed in first or last character");
            }
            else if (!checkEmail())
            {
                MessageBox.Show("‘@’ and ‘.’ sign cannot be placed next to each other");
            }
    
            else if (txtPassword.Text.Equals(""))
            {
                MessageBox.Show("Password must be filled");
            }
            else if (txtPassword.Text.Length < 6 && txtPassword.Text.Length > 50)
            {
                MessageBox.Show("Password must be between 6 – 50 characters");
            }
            else if(!checkAngka())
            {
                MessageBox.Show("Password must contain at least 1 number");
            }
            else if (txtConfirm.Text.Equals(""))
            {
                MessageBox.Show("Confirm Password must be filled");
            }
            else if(txtPassword.Text != txtConfirm.Text)
            {
                MessageBox.Show("Password does not match");
            }
            else if (txtPhone.Text.Equals(""))
            {
                MessageBox.Show("Phone Number must be filled");
            }
            else if (txtPhone.Text.Length < 9 && txtPhone.Text.Length > 12)
            {
                MessageBox.Show("Phone number must be between 9 – 12 characters");
            }
            else if (rdMale.Checked == false && rdFemale.Checked == false)
            {
                MessageBox.Show("Gender must be selected");
            }
            else if (rtxtAddress.Text.Equals(""))
            {
                MessageBox.Show("Address must be filled");
            }
            else if (!rtxtAddress.Text.EndsWith("Street"))
            {
                MessageBox.Show("Address must be ends with ‘Street’");
            }
            else
            {
                var id = (from x in dc.Users select x).Count()+1;
       
                MessageBox.Show("Successfuly Register");

                //dc.SubmitChanges();
            }
        }

        private bool checkAngka()
        {

            for (int i = 0; i < txtPassword.Text.Length; i++)
            {
                if (char.IsDigit(txtPassword.Text[i]))
                {
                    return true;
                }

            }

                return false;
        }

        private bool checkEmail()
        {
            var email = txtEmail.Text.Split('@');
        
            if (email[1].StartsWith("."))
            {
                return false;
            }
        
            return true;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            validate();
        }

        
    }
}
