﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Login : Form
    {
        Register regist = null;

        private DataClasses1DataContext dc = new DataClasses1DataContext();
       
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text.Equals(""))
            {
                MessageBox.Show("Email must be filled!");
            }
            else if (txtPassword.Text.Equals(""))
            {
                MessageBox.Show("Password must be filled!");
            }

            string email = txtEmail.Text;
            string pass = txtPassword.Text;

            var id = (from x in dc.Users
                      where x.Email == email && x.Password == pass
                      select x).FirstOrDefault();

            if (id != null)
            {
                this.Hide();
                new Main().Show();
            }
            else
            {
                MessageBox.Show("You are not registered as a member");
            }
        }

        private void lblRegist_Click_1(object sender, EventArgs e)
        {
            if(regist == null || regist.IsDisposed)
            {
                this.Hide();
                regist = new Register();
                regist.Show();
            }
        }

    }
}
